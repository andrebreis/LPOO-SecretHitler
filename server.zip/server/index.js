var app = require('express')();
var server = require('http').Server(app);
var io = require('socket.io')(server);

var playerIndex = 0;
var players = [];

var LIBERAL = 0;
var FASCIST = 1;
var HITLER = 2;

var presidentIndex = 0;
var noFascistLaws = 0;
var noLiberalLaws = 0;

var gameStarted = false;

server.listen(8080, function(){
  console.log("Server is now running...");
});

io.on('connection', function(socket){
  if(gameStarted)
    socket.disconnect('unauthorized');
  else{
  console.log("Player Connected!");
  socket.emit('getPlayers', players); // TODO: CHECK IF PLAYER JOINING ISNT RECEIVING HIMSELF ON THE PLAYERS ARRAY
  players.push(new player(socket.id, playerIndex++));
  socket.emit('idAndPosition', { id : socket.id, position : playerIndex - 1});
  socket.on('disconnect', function(){
    console.log("Player Disconnected!");
    socket.broadcast.emit('playerDisconnected', { id : socket.id});
    for(var i = 0; i < players.length; i++){
      if(players[i].id == socket.id){
        if(gameStarted){
          players[i].playing = false;
        }
        else {
          players.splice(i, 1);
          playerIndex--;
        }
      }
    }
  });
  socket.on('playerName', function(name){
    console.log("ping");
    for(var i = 0; i < players.length; i++){
      if(players[i].id == socket.id){
        players[i].name = name;
        //socket.emit('playerPosition', { position : players[i].position });
        socket.broadcast.emit('newPlayer', { id : socket.id, name : players[i].name, position: players[i].position});
        console.log(players);
      }
    }
  });
  socket.on('gameStart', function(){
    console.log("Game Started");
    gameStarted = true;
    assignRoles();
    var shuffledDeck = shuffleDeck();
    socket.emit('setDeckAndPlayers', { deck : shuffledDeck, players : players });
    socket.broadcast.emit('setDeckAndPlayers', { deck : shuffledDeck, players : players });
  });
//players.push(new player(socket.id, playerIndex++));
}
});

function player(id, position){
  this.id = id;
  this.position = position;
  this.playing = true;
  this.name = "";
  this.party = -1;
  this.role = -1;
}

function shuffleDeck(){

  var numLiberalCards = 6;
  var numFascistCards = 11;
  var noRandomNumbers = 1000;
  var policyDeck = [];

  while(numFascistCards + numLiberalCards > 0){
    var card = Math.floor(Math.random() * noRandomNumbers);
    if(card < noRandomNumbers/2 && numFascistCards > 0){
      numFascistCards--;
      policyDeck.push(FASCIST);
    }
    else if(numLiberalCards > 0) {
      numLiberalCards--;
      policyDeck.push(LIBERAL);
    }
  }
  return policyDeck;
}

function assignRoles(){
  var noLiberals;
  var noFascists;

  if(players.length == 5 || players.length == 6){
    noFascists = 2;
  }
  else if(players.length == 7 || players.length == 8){
    noFascists = 3;
  }
  else{ //(players.size() == 9 || players.size() == 10)
    noFascists = 4;
  }

  noLiberals = players.length - noFascists;

  var hitlerIndex = Math.floor(Math.random() * players.length);
  players[hitlerIndex].role = HITLER;
  players[hitlerIndex].party = FASCIST;
  noFascists--;

  while(noFascists > 0){
    var fascistIndex = Math.floor(Math.random() * players.length);
    if(players[fascistIndex].role == -1){
      players[fascistIndex].role = FASCIST;
      noFascists--;
    }
  }

  while(noLiberals > 0){
    var liberalIndex = Math.floor(Math.random() * players.length);
    if(players[liberalIndex].role == -1){
      players[liberalIndex].role = LIBERAL;
      noLiberals--;
    }
  }
}
